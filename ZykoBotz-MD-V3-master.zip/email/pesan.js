// virtex lu
const gmail1 = `
Hay Fitur eror yang anda gunakan sudah di Fix oleh moderator Samurai BOTZ
Jika ada fitur eror lainya ketik .report ya
Agar kami tangani secepatnya 

Thank you for using our Bot ☺️

const gmail = pickRandom([gmail1])

export default virtex;

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())]
}



/**
 * Jangan Di Hapus!!
 * 
 * Buatan @FokusDotId (Fokus ID)
 * Github: https://github.com/fokusdotid
 * 
 * Ingin bikin fitur tapi tidak bisa coding?
 * hubungi: https://wa.me/6281320170984
 * 
 */